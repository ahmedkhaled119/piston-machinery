# PISTON Digital Platform — Software Requirements Specification (SRS)

| Item | Value |
|---|---|
| Version | 0.3 (Draft — all 57 mockups reviewed, see §11) |
| Date | 2026-11-01 |
| Status | For stakeholder review |
| Source material | UI mockups in [docs/UI/Piston](../UI/Piston) + stakeholder answers |

> **Coverage note:** All 57 mockups reviewed — 8 visually, all 57 via text extraction (OCR). Layout details of OCR-only screens should be confirmed visually during UI design. Remaining **[TBC]** items have no dedicated screen in the mockups.

---

## 1. Introduction

### 1.1 Purpose
Define the functional and non-functional requirements of the PISTON digital platform: a public B2B marketing & lead-generation website and an internal Admin Portal.

### 1.2 Business Context
PISTON is a manufacturer of professional woodworking machinery (Industrial Area, 6th of October City, Giza, Egypt) selling machines and complete production lines to factories internationally (claims: 100+ projects, 50+ countries).

### 1.3 Business Goals
| ID | Goal | Success indicator |
|---|---|---|
| BG-01 | Generate qualified B2B leads | # of quote / engineer requests per month |
| BG-02 | Sell complete production lines, not single machines | Avg. machines per quote request |
| BG-03 | Build trust through proof (case studies, projects, testimonials) | Case study views → lead conversion |
| BG-04 | Reduce after-sales load via self-service support | Support tickets vs. manual/FAQ views |
| BG-05 | Reach international markets | Traffic & leads by country / language |
| BG-06 | Let the internal team manage everything without developers | 100% of public content editable from Admin Portal |

### 1.4 Scope
**In scope (MVP):**
- Public website (responsive: desktop, tablet, mobile)
- Admin Portal (CMS + leads + support + administration)
- Multilingual content: English and Arabic (RTL) at launch; architecture must allow adding languages later
- Planning tools: Production Line Builder (UI deferred — Q-15), Machine Finder, Custom Solutions request
- Quote requests via direct WhatsApp conversation with PISTON sales (no web RFQ form, no tracking)
- Integrations: Email notifications, WhatsApp (click-to-chat), Google Analytics 4
- Hosting: on-premises / local Egyptian hosting

**Out of scope (MVP):**
- Customer login / customer portal (all customer interactions are public forms or WhatsApp)
- Web RFQ form, RFQ reference numbers and RFQ / ticket status tracking
- Online payment / checkout (planned for a later phase — see §9)
- ERP / CRM integration
- Live chat
- Factory Layout Planning
- Careers section
- Languages other than English and Arabic

### 1.5 Definitions
| Term | Meaning |
|---|---|
| RFQ | Request for Quotation — in MVP, a WhatsApp conversation started from the website |
| Quote list | Browser-session list of machines/parts the visitor wants a quote for; sent as one pre-filled WhatsApp message |
| Lead | Any inbound request stored by the system: engineer request, contact message, meeting request, support request, submission, newsletter subscription (WhatsApp quote conversations are outside the system) |
| Production Line | Ordered set of machines covering a manufacturing process |
| BOQ | Bill of Quantities |
| RTL | Right-to-left layout (Arabic) |

---

## 2. Overall Description

### 2.1 User Classes
| Role | Type | Description |
|---|---|---|
| Visitor / Prospect | External, anonymous | Factory owners, managers, engineers, workshop owners researching machinery |
| Existing Customer | External, anonymous | Seeks support, manuals, spare parts (no login in MVP) |
| Administrator | Internal | Full access incl. users, roles, settings, logs |
| Content Editor | Internal | Creates/updates content (products, news, media, events) |
| Sales Engineer | Internal | Handles quote conversations on WhatsApp (outside the system), engineer & meeting requests |
| Support Agent | Internal | Handles support tickets and spare-part requests |

### 2.2 Operating Environment
- Modern browsers (latest 2 versions of Chrome, Edge, Firefox, Safari; iOS Safari, Android Chrome)
- On-premises / local Egyptian hosting (infrastructure details to be defined in Design phase)

### 2.3 Constraints
- Brand identity per mockups: dark/black base, red accent, white content areas, bold uppercase headings
- Must support RTL layout for Arabic
- Must comply with Egypt Personal Data Protection Law (No. 151/2020) and GDPR for EU visitors (EU leads shown, e.g. Poland, Romania, Germany events)
- Must run on on-premises / local Egyptian hosting; no dependency on a specific public-cloud PaaS

### 2.4 Assumptions
- A-01: No customer accounts and no request tracking; quotes continue directly on WhatsApp between customer and company.
- A-02: No prices are shown publicly (machines or spare parts); all sales are quote-based (Q-12).
- A-03: Product technical data is maintained in the Admin Portal (no RFQ summary calculations in MVP).
- A-05: PISTON operates its WhatsApp number(s) with WhatsApp Business (app) and staff respond within the published 24-hour promise.
- A-04: Content will be translated by PISTON staff (no machine-translation requirement).

---

## 3. Functional Requirements

Priority: **M** = Must, **S** = Should, **C** = Could (MoSCoW).

### 3.1 Global / Shell (GEN)
| ID | Requirement | Pri |
|---|---|---|
| GEN-01 | Header with logo, mega-menu (Products, Industries & Solutions, Support, About Piston, Contact), search box, language selector, persistent "Request a Quote" button (opens WhatsApp — RFQ-01) | M |
| GEN-02 | Breadcrumb navigation on all inner pages | M |
| GEN-03 | Footer with columns: Products, Industries & Solutions, Solutions, Support, Company, Contact Us, social links (LinkedIn, YouTube, Facebook, Instagram), Privacy Policy, Terms of Use, Sitemap | M |
| GEN-04 | Global search across machines, solutions, content (placeholder "Search machines, solutions…") | M |
| GEN-04a | Search results page: result tabs with counts (All, Machines, Solutions, Support Manuals, Spare Parts, Articles & News); refine filters (content type, industry, machine type); sort by relevance; "Did you mean"/suggested searches; popular searches; "Can't find it? Submit a request" | M |
| GEN-11 | Newsletter signup block in footer / content pages | S |
| GEN-05 | Language switch preserves the current page; Arabic renders RTL | M |
| GEN-06 | Reusable CTA strip ("Ready to achieve results like these?") with Build Production Line / Request a Quote / Talk to an Engineer | M |
| GEN-07 | Responsive layout for desktop, tablet, mobile | M |
| GEN-08 | ~~Live chat widget~~ — removed from MVP (Q-06) | — |
| GEN-09 | WhatsApp click-to-chat button | M |
| GEN-10 | Cookie consent banner controlling analytics | M |

### 3.2 Product Catalogue (CAT)
| ID | Requirement | Pri |
|---|---|---|
| CAT-01 | Product listing with category sidebar showing item counts (e.g. Panel Processing, Edge Banding, Drilling & Routing, Material Handling, Automation & Controls, Saws) | M |
| CAT-02 | Listing supports search, sort, pagination, 3-column card grid | M |
| CAT-03 | "Need help choosing?" entry point to Machine Finder / expert | S |
| CAT-04 | Product detail: image gallery, model code & name, CTAs (Request Quote, Talk to Engineer, Download Brochure) | M |
| CAT-05 | Product detail tabs: Overview, Key Features, Technical Specifications, Videos, Downloads, Related Products | M |
| CAT-06 | Technical specifications table driven by structured data | M |
| CAT-07 | "Add to quote list" from listing and detail page (RFQ-03); "Request a Quote" on a product opens WhatsApp with that product | M |
| CAT-08 | Related products carousel | S |
| CAT-09 | Listing filters: Industry, Machine Type, Power range (kW slider), Capacity (min/max), Application, Availability (In Stock / Made to Order); category tabs; grid/list toggle; "Featured" badge | M |
| CAT-10 | Compare machines: "Add to Compare" on cards, sticky compare bar (n selected), side-by-side comparison | S |
| CAT-11 | ~~Product rating display~~ — removed from MVP (Q-13); remove from product mockups | — |
| CAT-12 | Download datasheet (PDF) per product | M |
| CAT-13 | **360° product viewer** (MVP, Q-21): photo-based spin with drag/zoom/fullscreen, clickable hotspots linking to a component list with per-component description & specs. True interactive 3D (exploded view, isolation, measure, share view, 3D model download) → Phase 2 | S |
| CAT-14 | Product page sections for Spare Parts, Technical Support and operation videos for that machine | M |
| CAT-15 | Warranty and origin info (e.g. 2-year warranty on standard machines) | S |

### 3.3 Industries & Solutions (IND)
| ID | Requirement | Pri |
|---|---|---|
| IND-01 | Industry detail page for each of 6 industries: Furniture, Cabinet, Door, Interior Production, Woodworking Workshops, Industrial Production | M |
| IND-02 | Industry tabs to switch between industries | M |
| IND-03 | Sections: hero, "Why Piston" points, About industry, Typical Production Process (ordered steps), Recommended Piston Solution (ordered machine chain), Key Benefits (metrics), Talk to an Expert, Applications, Success Stories, Popular Machines | M |
| IND-04 | Download industry brochure | S |
| IND-05 | "View detailed solution" / "Build your production line" adds the recommended machines to the quote list | S |
| IND-06 | Industries & Solutions overview: industry cards with solution count and installation count, sort, "Explore by industry" with process/recommended solution preview, global stats, newsletter | M |
| IND-07 | ~~Financing Options block~~ — removed; no financing offered (Q-14) | — |
| IND-08 | Workshop variant: "Recommended Workshop Setup" and "Build your workshop solution" for Woodworking Workshops | S |

### 3.4 Solution Tools (SOL)
In MVP per Q-03.

| ID | Requirement | Pri |
|---|---|---|
| SOL-01 | Production Line Builder: compose a line from machines; output goes to the quote list / WhatsApp. **No dedicated screen in mockups** — UI decision deferred **[Q-15]** | M |
| SOL-02 | Machine Finder — 5-step wizard: 01 Industry → 02 Operation → 03 Material → 04 Production → 05 Results; step indicator "Step n of 5"; Back / Next | M |
| SOL-02a | Industry (single): Furniture, Cabinet, Door, Interior Production, Woodworking Workshops, Other | M |
| SOL-02b | Operation: Cutting, Edge Banding, Pressing, Drilling, Other | M |
| SOL-02c | Material (multi-select): MDF, Plywood, Solid Wood, Laminate, Particle Board, Multiple | M |
| SOL-02d | Production: volume (Low / Medium / High / Very High), precision level, workshop size | M |
| SOL-02e | Results: Best Match with match score %, "Why we recommend this" reasons, Other great options with scores, Complete solution for the selected industry, actions (View details, Compare, Request a Quote, Build Production Line, Talk to an Expert) | M |
| SOL-02f | Sidebar "Your Selection Summary" and live recommendation preview updating per step | S |
| SOL-02g | "No time to explore? Schedule a call" | S |
| SOL-03 | Factory Layout Planning — Phase 2 | — |
| SOL-04 | Custom Solutions request page | M |

### 3.5 Request for Quotation (RFQ) — via WhatsApp
> **Decision (Q-02, Q-04, Q-08, Q-11, Q-16):** Quote requests are a direct WhatsApp conversation between the customer and PISTON, with no tracking. There is no web RFQ form, reference number, confirmation email, status page or file upload for quotes. The RFQ mockups (06.09.03, 06.11.49, 06.13.55, 06.15.18, 06.17.38, 07.46.20) are **not implemented** in MVP.

| ID | Requirement | Pri |
|---|---|---|
| RFQ-01 | Every "Request a Quote" CTA (header, product cards & pages, industry pages, Machine Finder results, case studies, events, CTA strips) opens a WhatsApp chat with the PISTON sales number via click-to-chat | M |
| RFQ-02 | The chat opens with a pre-filled message in the visitor's language: greeting, product model(s) & name(s), quantities (if from the quote list), and the source page (e.g. Machine Finder, industry page). The visitor can edit it before sending | M |
| RFQ-03 | Quote list (browser session only, no login): add machines from listing, product page, recommended solution or Machine Finder; change quantity; remove; "Send via WhatsApp" sends all items in one message | S |
| RFQ-04 | Desktop fallback: if WhatsApp isn't installed, show the number and a QR code to continue on a phone | S |
| RFQ-05 | Short notice before redirect that the conversation continues on WhatsApp (subject to WhatsApp's terms) | M |
| RFQ-06 | WhatsApp numbers (Sales, Spare Parts) and message templates per language are managed in Admin settings | M |
| RFQ-07 | Anonymous quote-click log: product(s), source page, language, country (coarse, from IP), timestamp — **no personal data**; feeds the Admin dashboard and GA4 | S |
| RFQ-08 | Drawings, BOQs and requirements are exchanged directly in the WhatsApp chat, not uploaded to the website | — |

### 3.6 Other Leads (LEAD)
| ID | Requirement | Pri |
|---|---|---|
| LEAD-01 | Talk to an Engineer form: Name*, Email*, Phone, Company*, Job Title, Country*, Subject, Machine/model of interest, Inquiry description*, attachments (PDF, DWG, XLS, DOC, JPG; 20 MB each); "Send to Engineer"; reply within 24 business hours | M |
| LEAD-02 | Contact page form: Full Name*, Company*, Country*, Email*, Phone*, **Inquiry Type*** (Sales Inquiry, Technical Support, Spare Parts, Production Solution, Distributor Inquiry), Message* | M |
| LEAD-03 | Event-specific contact form (linked to event) | M |
| LEAD-04 | Schedule a meeting (e.g., at event booth) | S |
| LEAD-05 | Newsletter subscription with double opt-in | S |
| LEAD-06 | All lead forms protected against spam (CAPTCHA/rate limit) | M |
| LEAD-07 | Distributor inquiry ("Become a distributor") | S |
| LEAD-08 | Public submissions: "Submit your story / project / video" form (contact info, title, description, files/links, consent); submissions never auto-publish — admin approves (Q-17) | S |

### 3.7 Content Hub (CNT)
| ID | Requirement | Pri |
|---|---|---|
| CNT-01 | Hub "News, Case Studies & Projects" with content-type tabs and counts: All, Case Studies, Projects, News, Videos | M |
| CNT-02 | Case study listing: filters by Industry, Solution Type, Country/Region, Results Achieved (with counts), sort, pagination | M |
| CNT-03 | Case study card: image, location, title, industry, solution, summary, up to 3 result metrics | M |
| CNT-04 | Project / Case study detail tabs: Overview, Challenge, Solution, Installation, Results, Customer Feedback, Gallery, Documents | M |
| CNT-05 | Detail header: location, industry, year, summary, 4 KPI cards, featured quote | M |
| CNT-06 | "Project at a Glance": machines installed, before→after metrics, duration, customer since | M |
| CNT-07 | Testimonials: author, job title, company, rating (1–5), text; carousel | M |
| CNT-08 | Key Feedback Areas tiles | C |
| CNT-09 | Share (LinkedIn, Facebook, email, copy link) | S |
| CNT-10 | News listing & article detail with categories, related news, newsletter | M |
| CNT-10a | News categories: Company News/Updates, Industry Insights, Events & Exhibitions, Technology, Partners; featured news; upcoming events widget | M |
| CNT-11 | Videos: featured & latest videos, categories (Machine Demos, Installation Stories, Factory Tours, Customer Stories, Technology & Innovation, Maintenance Tips, Events), playlists, view counts, YouTube subscribe link | S |
| CNT-11a | Projects listing: filters Industry, Project Type (New Line, Capacity Expansion, Automation Integration, Modernization…), Country/Region, Year | M |
| CNT-11b | Case study Overview tab: customer profile, "The Journey" (Challenge → Requirements → Solution Design → Installation → Training), project type/duration/completion date, project video | M |
| CNT-11c | Installation tab: installation timeline (dates, duration), steps (planning, delivery, site preparation, installation, testing & commissioning), highlights | M |
| CNT-11d | Gallery tab: photo categories with counts, load more, expand; Documents tab: list with type, size, date, search, sort, download | M |
| CNT-12 | Events & Exhibitions: detail tabs Overview, What to Expect, Our Solutions, Event Details, Location, Contact Us; actions Add to Calendar, Register to Visit, Share; "Who should attend"; featured machines on display | M |
| CNT-12a | Event Location tab: venue address, map, directions (car, train, airport), Get Directions | S |
| CNT-13 | Event data: dates, city/country, booth (hall/stand), gallery, team members attending, brochure, plan-your-visit links (floor plan, travel, hotels, visa) | M |
| CNT-14 | Event "Our Solutions" tab: filterable list of machines exhibited | S |

### 3.8 Support (SUP)
| ID | Requirement | Pri |
|---|---|---|
| SUP-01 | Support Center landing: search (manuals, machines, parts, videos, FAQ), tiles (Manuals, Maintenance, Spare Parts, Videos, Technical Support, FAQ, Troubleshooting) | M |
| SUP-01a | "Find support for your machine": select machine + optional model/serial number → machine-specific resources; "Where to find your serial number?" help; "Browse all machines" | M |
| SUP-02 | Documents per machine: User Manual, Installation Guide, Maintenance Guide, Electrical & Pneumatic Diagrams, Troubleshooting Guide, Safety Instructions, Software Updates | M |
| SUP-03 | Video Center: machine overview, setup, operation, daily maintenance videos with duration | S |
| SUP-04 | Technical assistance request (no login): Expert Support, Remote Assistance, On-site Service; product/model, serial no., issue, attachments | M |
| SUP-05 | ~~Ticket status lookup~~ — no tracking in MVP (Q-04) | — |
| SUP-06 | Spare Parts: search by part name/number/model; select machine; navigate machine components (e.g. 12 for R32); parts list per component; part details (part no. e.g. `PM-R32-001`, description, compatibility, stock status, warranty) — **no prices** (Q-12); "Add to parts list" with quantities; **Request Quote opens WhatsApp (Spare Parts number) with part numbers & quantities** (Q-08); popular replacement parts | M |
| SUP-06a | "Need help identifying a part?" — upload photo (JPG/PNG ≤ 5 MB); "Contact parts specialist" | S |
| SUP-06b | Parts service info: genuine parts, worldwide shipping, 12-month warranty, 30-day returns | S |
| SUP-07 | FAQ with search and categories | M |
| SUP-08 | Support contact block: phone, support hours and reply promise from Admin settings (ADM-15a), Global Service Network | M |

### 3.9 Company (COM)
| ID | Requirement | Pri |
|---|---|---|
| COM-01 | About Piston: hero, Our Story, Manufacturing Capabilities (Engineering, R&D, CNC machining, Assembly, Quality Control, Testing), Factory Tour & company videos, Piston by the Numbers, Global Service & Support, Operator & maintenance training | M |
| COM-02 | Quality & Certifications (certification logos, standards) — section on About page; dedicated page **[TBC]** | S |
| COM-03 | Careers — Phase 2 (Q-09); hide footer link in MVP | — |
| COM-04 | Contact page: "How can we help you?" cards (Sales Inquiry, Technical Support, Spare Parts, Production Solution, Distributor Inquiry), contact form (LEAD-02), Global Presence map, Global Sales phones & emails (sales@, info@), Factory & HQ address, business hours (from Admin settings — ADM-15a), WhatsApp chat, Downloads (manuals, catalogs), Find a local distributor, Support Center link | M |
| COM-06 | Distributor locator ("Find a local distributor") **[Deferred — Q-18]** | — |
| COM-05 | Legal pages: Privacy Policy, Terms of Use, Sitemap | M |

### 3.10 Admin Portal (ADM)
| ID | Requirement | Pri |
|---|---|---|
| ADM-01 | Admin sign-in: email + password, Remember me, language selector; MFA for Administrator (not shown in mockup — required by NFR-06) | M |
| ADM-01a | Forgot password: request reset link by email; Reset password with policy (≥ 8 chars, upper, lower, number, special) and strength meter; success screen | M |
| ADM-02 | Dashboard: KPI cards (Products, Industries, Projects, **WhatsApp Quote Clicks**, Engineer Requests, Support Tickets, News, Events) with trend & sparkline; date-range filter | M |
| ADM-03 | Dashboard widgets: Lead Activity chart, **Recent Quote Clicks** (products, source page, country, time), Content Overview donut, Recent Activity, Support Ticket overview, Upcoming Events | S |
| ADM-04 | Global admin search (Ctrl/⌘+K) | S |
| ADM-05 | "+ Add Content" quick action | S |
| ADM-06 | CMS for: Homepage, Products (+categories, specs, galleries, downloads), Industries & Solutions, Projects, Case Studies, News, Videos, Events & Exhibitions | M |
| ADM-07 | Content workflow: Draft → Published (→ Archived); scheduled publishing | M |
| ADM-08 | Per-language content versions and translation status per item | M |
| ADM-09 | Support management: Support Center, Spare Parts, Maintenance Videos, Technical Support tickets, FAQ | M |
| ADM-10 | Leads inbox: Engineer Requests, Contact Messages, Meeting Requests, Support Requests, Newsletter Subscribers — with unread counters. (No Quote Requests inbox — quotes are on WhatsApp.) | M |
| ADM-11 | Lead handling: assign to user, change status, internal notes, attachments download, export (CSV/Excel) | M |
| ADM-12 | Media Library (images, videos, PDFs) with alt text per language | M |
| ADM-13 | Customers registry (companies from leads/projects) | S |
| ADM-14 | Users & Access: create users, assign roles, role-based permissions | M |
| ADM-15 | Settings: Website (contact info, social links), SEO (meta, redirects, sitemap), Localization (languages, default language, RTL) | M |
| ADM-15a | **Company facts & hours** (Q-22): editable company stats (years of experience / founded year, countries served, machines installed, projects delivered, distributors, customer satisfaction %) and business hours per channel (Sales, Support, Spare Parts) with days, times and timezone. Every page showing stats or hours reads from these settings | M |
| ADM-15b | **WhatsApp settings**: numbers per channel (Sales, Spare Parts, Support) and pre-filled message templates per language (RFQ-06) | M |
| ADM-16 | Audit Logs (security-relevant) and Activity Logs (content actions: who, what, when) | M |
| ADM-17 | In-app notifications (new leads, ticket updates) | S |
| ADM-18 | Submissions moderation queue: review, edit, approve (convert to Case Study / Project / Video draft) or reject public submissions | S |

### 3.11 Integrations (INT)
| ID | Requirement | Pri |
|---|---|---|
| INT-01 | Transactional email: confirmations to customer, notifications to internal team, templates per language | M |
| INT-02 | Google Analytics 4: page views + conversion events (WhatsApp quote click, WhatsApp parts click, engineer request, brochure download, contact submit) | M |
| INT-03 | WhatsApp click-to-chat (`https://wa.me/<number>?text=<url-encoded message>`) — the **main quote channel**; no WhatsApp Business API | M |
| INT-04 | ~~Live chat~~ — removed from MVP (Q-06) | — |

---

## 4. Business Rules
| ID | Rule |
|---|---|
| BR-01 | Every lead stored by the system (engineer, contact, meeting, support request, submission) receives a unique human-readable reference (e.g. `ENG-2026-000123`). WhatsApp quotes have no reference. |
| BR-02 | ~~RFQ statuses~~ — not applicable; quotes are managed in WhatsApp (Q-11). |
| BR-03 | Support ticket statuses: **New → In Progress → Waiting → Resolved** (→ Closed). |
| BR-04 | Event statuses: **Draft → Upcoming → Ongoing → Past**; only non-Draft are public. |
| BR-05 | Target response time to WhatsApp quote messages: within 24 hours (public promise). |
| BR-06 | Upload limits per form (Q-19): Talk to an Engineer — PDF, DWG, XLS, DOC, JPG, PNG ≤ 20 MB/file; spare-part photo — JPG, PNG ≤ 5 MB. All files virus-scanned before staff access; limits configurable in Admin settings. (No uploads for quotes — RFQ-08.) |
| BR-12 | Public submissions are stored as pending and are only visible publicly after admin approval. |
| BR-07 | ~~RFQ summary calculations~~ — not applicable (Q-02). |
| BR-08 | Listing/filter counts reflect only published content in the current language. |
| BR-09 | Content not translated to the selected language falls back to English with a visible notice. |
| BR-11 | Personal data from leads is retained for 2 years after last activity, then deleted or anonymized. |
| BR-10 | Phone numbers stored in E.164 format. |
| BR-13 | Company stats and business hours are never hard-coded; all pages read them from Admin settings (ADM-15a). |
| BR-14 | The quote list holds max 20 items and lives only in the visitor's browser; it is never stored on the server. |

### 4.1 Quote Flow (WhatsApp)
```mermaid
sequenceDiagram
    actor V as Visitor
    participant W as Piston Website
    participant WA as WhatsApp
    actor S as Piston Sales
    V->>W: Click "Request a Quote" (or send quote list)
    W->>W: Build pre-filled message (language, models, qty, source page)
    W->>W: Log anonymous quote click + GA4 event
    W->>WA: Open wa.me/<sales number>?text=...
    V->>WA: Review & send message
    WA->>S: Message delivered
    S->>V: Reply within 24 h, exchange details & quotation in chat
```

---

## 5. Non-Functional Requirements
| ID | Category | Requirement |
|---|---|---|
| NFR-01 | Performance | Public pages LCP ≤ 2.5 s on 4G; Admin pages ≤ 3 s |
| NFR-02 | Performance | Search results ≤ 1 s for p95 |
| NFR-03 | Availability | Public site 99.5% monthly (on-premises target; revisit after infrastructure design) |
| NFR-04 | Scalability | Handle trade-show traffic spikes (e.g. LIGNA) ×10 normal load; CDN/edge caching for static assets recommended given on-premises hosting and international visitors |
| NFR-05 | Security | OWASP Top 10 mitigations; HTTPS only; security headers (CSP, HSTS) |
| NFR-06 | Security | RBAC on all admin endpoints; MFA for admins; lockout after failed logins |
| NFR-07 | Security | Upload validation (type by content, size), malware scan, private storage, time-limited download links |
| NFR-08 | Security | Bot/spam protection on all public forms; rate limiting |
| NFR-09 | Privacy | Consent capture, 2-year lead retention (BR-11), right to erasure, Egypt PDPL & GDPR |
| NFR-10 | Accessibility | WCAG 2.1 AA (contrast of red-on-dark must be validated) |
| NFR-11 | SEO | Server-side rendered public pages, per-language URLs with `hreflang`, XML sitemap, schema.org (Product, Organization, Event, Article) |
| NFR-12 | Localization | Full UI + content localization for EN and AR; RTL mirroring for Arabic; localized dates/numbers; adding a new language must be configuration + translation only (no code change) |
| NFR-13 | Maintainability | Content changes require no deployment |
| NFR-14 | Observability | Centralized logs, error tracking, uptime monitoring |
| NFR-15 | Backup | Daily backups with an off-site copy, RPO ≤ 24 h, RTO ≤ 4 h |
| NFR-16 | Auditability | Admin actions retained ≥ 1 year |

---

## 6. Data Requirements (Conceptual Entities)
| Entity | Key attributes |
|---|---|
| ProductCategory | name*, slug, order, icon |
| Product | model code, name*, category, summary*, features*, specs (key/value/unit)*, footprint (L×W m), power (kW), process stage, gallery, videos, downloads, related products, status |
| Industry | name*, slug, hero*, about*, why-points*, benefits (value,label)*, applications*, brochure*, process steps*, recommended machines (ordered) |
| ProcessStep | industry, order, name*, description* |
| CaseStudy / Project | type (CaseStudy/Project), title*, slug, location (city, country), industry, solution type, year, summary*, KPIs, challenge*, solution*, installation*, results*, before/after metrics, duration, machines, customer, gallery, documents, featured quote |
| Testimonial | author, job title, company, rating 1–5, text*, photo |
| NewsArticle | title*, category, body*, cover, author, publish date, tags |
| Video | title*, category, playlist, provider URL, duration, thumbnail |
| Event | name*, dates, city/country, venue, booth (hall, stand), status, gallery, exhibited products, team members, brochure, visit links |
| TeamMember | name, job title*, email, photo |
| QuoteClick | channel (Sales/Parts), items (product or part no., qty), source page, language, country (coarse), timestamp — anonymous, no personal data |
| EngineerRequest / ContactMessage / MeetingRequest | reference, contact info, subject, message, related entity (product/event/case), status, assignee |
| NewsletterSubscriber | email, language, consent date, confirmed |
| SupportTicket | reference, customer contact, product, serial no., issue, attachments, status, assignee |
| SparePart | part no., name*, description*, compatible machines, component, diagram position, image, stock status, warranty |
| Submission | type (story/project/video), submitter contact, title, description, files/links, consent, status (Pending/Approved/Rejected), reviewer, linked content |
| MachineComponent | product, order, name*, description*, specs, 3D hotspot/position, image |
| SupportDocument | product, type (manual, installation, maintenance, diagram, troubleshooting, safety, software), language, file, version |
| Distributor | name, country, region, contact, address, location |
| MachineFinderRule | criterion (industry/operation/material/production), option, product, weight |
| FAQ | question*, answer*, category |
| Customer | company, country, contacts, related leads/projects |
| User / Role / Permission | name, email, role, MFA, status |
| MediaAsset | file, type, size, alt text*, usage |
| AuditLog / ActivityLog | actor, action, target, timestamp, IP |
| Setting | key, value (incl. SEO, localization, contact info, WhatsApp numbers & templates) |
| CompanyFacts | stat key (years, countries, machines installed, projects, distributors, satisfaction), value, label* |
| BusinessHours | channel (Sales/Support/Parts), days, open/close time, timezone, closed days, note* |

`*` = translatable per language.

---

## 7. External Interface Requirements
- **UI:** per mockups in [docs/UI/Piston](../UI/Piston).
- **Email:** SMTP/transactional email service.
- **Analytics:** GA4 via consent-aware tag.
- **WhatsApp:** click-to-chat link (`wa.me`) with pre-filled text — main quote channel; numbers & templates from Admin settings.
- **Video:** YouTube embeds (channel exists in footer).

---

## 8. Design Issues Found in Mockups (to fix in UI)
| Screen | Issue |
|---|---|
| 06.30.19 Industry – Cabinet | Process step "Drilling" numbered **2** instead of 3 |
| 07.58.14 Industry – Furniture | Solutions cards numbered 01, 02, 03, **04, 04** — fifth card should be 05 |
| 07.25.41 Event – Details | Exhibition hours contradictory ("Mon – Fri 9–6" and "Fri 9–5") |
| 08.10.19 Admin – Reset password | Strength meter shows "Strong" on 2 of 3 bars — demo treats 3rd bar as "Very strong" (14+ chars) |
| 07.06.21 Project – Customer Feedback | Hossam Mohsen card shows 4 stars but rating **5.0** |
| 08.10.24 Admin Dashboard | Typo "Conteets" → "Contents" |
| Multiple | Footer copyright "© 2024" — should be dynamic |
| Multiple | Footer Support column differs between screens ("User Manuals" vs "Support Center") |
| Multiple | Main nav inconsistent: "Industries" + "Solutions" (early screens) vs merged "Industries & Solutions" (later screens) |
| Multiple | Company stats inconsistent: countries 50+ / 60+ / 80+; machines installed 1,200+ / 5,000+ / 10,000+; years 25+ (since 1998) / 20+ — **resolved: values come from Admin settings (ADM-15a)** |
| Multiple | Business hours inconsistent: Sun–Thu 08:00–17:00, Sun–Thu 08:00–18:00 (Cairo), Mon–Fri 08:00–17:00 (CET) — **resolved: per-channel hours from Admin settings (ADM-15a)** |
| Multiple | Product taxonomy inconsistent: Sliding Table Saws / Edge Banding / Vacuum Presses / Drilling / Other vs Panel Processing / Edge Banding / Drilling & Routing / Material Handling / Automation & Controls / Saws |
| Multiple | Footer still shows Careers and Factory Layout Planning (out of MVP) |
| 06.04.46 3D Viewer | Breadcrumb typo "Pliding Table Saws" |
| 06.11.49 RFQ Confirmation | Submitted date shows 2024 while reference is RFQ-2026-… (screen not implemented in MVP) |
| All RFQ screens | Mockups must be updated: "Request a Quote" opens WhatsApp; RFQ wizard, confirmation, tracking and single-page quote screens are dropped for MVP |
| Admin login, events | Unexplained "SPEED EDGE" brand mark **[Q-20]** |

---

## 9. Future Phases
| Phase | Feature |
|---|---|
| Phase 2 | Online payment & checkout for spare parts |
| Phase 2 | Optional customer portal (track RFQs/tickets, saved machines) |
| Phase 2 | Web RFQ form with reference number, file upload, summary & tracking (mockups 06.09.03–06.17.38, 07.46.20) |
| Phase 2 | CRM integration |
| Phase 2 | Additional languages beyond EN/AR |
| Phase 2 | Factory Layout Planning |
| Phase 2 | Careers section |
| Phase 2 | Live chat |
| Phase 2 | True interactive 3D viewer (exploded view, measure, 3D model download) |
| Phase 2 | Product ratings & reviews (needs customer accounts) |
| Phase 3 | Dealer / distributor portal |

---

## 10. Decisions Log (Open Questions)
| # | Question | Decision | Status |
|---|---|---|---|
| Q-01 | Languages at launch? | English + Arabic; others later | Resolved |
| Q-02 | Formula for RFQ footprint & capacity level? | Not applicable — quotes via WhatsApp, no RFQ summary | Resolved |
| Q-03 | Planning tools in MVP? | Production Line Builder, Machine Finder, Custom Solutions. Factory Layout Planning → Phase 2 | Resolved |
| Q-04 | Public RFQ/ticket status tracking? | No tracking; direct WhatsApp contact | Resolved |
| Q-05 | Untranslated content behaviour? | Fall back to English with a notice | Resolved |
| Q-06 | WhatsApp / live chat? | WhatsApp click-to-chat only; no live chat | Resolved |
| Q-07 | Lead data retention? | 2 years | Resolved |
| Q-08 | Spare-parts request flow? | Parts list sent via WhatsApp (Spare Parts number) | Resolved |
| Q-09 | Careers in MVP? | Not in MVP | Resolved |
| Q-10 | Hosting? | On-premises / local Egyptian hosting | Resolved |
| Q-11 | Is the whole RFQ module in MVP, or only its details deferred? | RFQ = direct WhatsApp contact between customer and company, no tracking; web RFQ form → Phase 2 | Resolved |
| Q-12 | Spare-part prices public? | Quote-only; no prices shown | Resolved |
| Q-13 | Product ratings/reviews? | Removed from MVP | Resolved |
| Q-14 | Financing offered? | No — remove block | Resolved |
| Q-15 | Production Line Builder has no dedicated screen. Design needed, or reuse RFQ machine selection? | Skipped for now | Deferred |
| Q-16 | Two quote forms exist (3-step wizard vs single page 07.46.20). Which one is final? | Neither in MVP — WhatsApp | Resolved |
| Q-17 | Public submissions in MVP? | Yes, admin-moderated | Resolved |
| Q-18 | Distributor network: is there distributor data to show (locator map)? | Skipped for now | Deferred |
| Q-19 | Unified upload size limit? | Keep per-form limits as in mockups (50 / 20 / 5 MB) | Resolved |
| Q-20 | What is "SPEED EDGE" (sub-brand, product line, or leftover)? | — | Open |
| Q-21 | 3D viewer in MVP? | MVP = 360° photo spin; true 3D → Phase 2 | Resolved |
| Q-22 | Official company stats and business hours (see §8 inconsistencies)? | Managed from the Admin Portal (ADM-15a) | Resolved |

---

## 11. Traceability — Mockups
Review method: **V** = visual review, **T** = text extraction (OCR) only. Low-text screens (L) are mostly imagery/boards and need visual confirmation.

| Screenshot (2026-08-20) | Screen | Modules | Review |
|---|---|---|---|
| 05.15.17 | Home page | GEN, CAT, SOL, IND | T |
| 05.21.01 | Machinery listing (filters, compare) | CAT | T |
| 05.27.35 | Product detail – R32 | CAT, SUP | T |
| 05.36.38 | Machine Finder – Step 1 + live preview | SOL | T |
| 05.42.50 | Machine Finder – all 5 steps board | SOL | T |
| 05.59.15 | R32 Interactive 3D Viewer | CAT-13 | T |
| 06.04.46 | R32 3D Viewer – component selected | CAT-13 | T |
| 06.04.48 | R32 components exploded board | CAT-13 | T |
| 06.09.03 | Request a Quote – Step 1 | Phase 2 (MVP = WhatsApp, RFQ-01) | V |
| 06.11.49 | RFQ – Request Received | Phase 2 | T |
| 06.13.55 | Request a Quote – Step 2 | Phase 2 | T |
| 06.15.18 | Request a Quote – Step 3 Review | Phase 2 | T |
| 06.17.38 | RFQ Tracking | Phase 2 | T |
| 06.22.10 | Technical Support / Support Center (v1) | SUP | T |
| 06.22.10_1 | Support Center (v2) | SUP | T |
| 06.25.05 | Spare Parts | SUP-06 | T |
| 06.27.33 | Industries & Solutions overview | IND | T |
| 06.30.19 | Industry – Cabinet Manufacturing | IND | V |
| 06.31.33 | Industry – Door Manufacturing | IND | T |
| 06.32.57 | Industry – Interior Production | IND | T |
| 06.34.19 | Industry – Woodworking Workshops | IND | T |
| 06.35.36 | Industry – Industrial Production | IND | T |
| 06.37.47 | About Piston | COM | T |
| 06.39.59 | Contact Piston | COM, LEAD | T |
| 06.41.54 | Search Results | GEN-04a | T |
| 06.44.21 | News, Case Studies & Projects hub | CNT | T |
| 06.48.01 | Case Studies listing | CNT | V |
| 06.50.22 | Projects listing | CNT | T |
| 06.51.53 | News & Insights listing | CNT | T |
| 06.53.33 | Videos | CNT | T |
| 06.55.13 | Case study – Overview | CNT | T |
| 06.58.47 | Project – Challenge | CNT | T |
| 07.00.29 | Project – Solution | CNT | T |
| 07.03.05 | Project – Installation | CNT | T |
| 07.05.00 | Project – Results | CNT | T |
| 07.06.21 | Project – Customer Feedback | CNT | V |
| 07.07.48 | Project – Gallery | CNT | T |
| 07.09.12 | Project – Documents | CNT | T |
| 07.12.15 | News article detail | CNT | T |
| 07.14.01 | Event LIGNA 2025 – Overview | CNT | T |
| 07.15.21 | Event LIGNA 2025 – What to Expect | CNT | T |
| 07.22.00 | Event LIGNA 2025 – Our Solutions | CNT | T |
| 07.25.41 | Event LIGNA 2025 – Event Details | CNT | T |
| 07.27.03 | Event LIGNA 2025 – Location | CNT | T |
| 07.28.53 | Event LIGNA 2025 – Contact Us | CNT, LEAD | V |
| 07.34.21 | Products → Product Details flow board | CAT | V |
| 07.44.14 | Support Center sections board | SUP | T (L) |
| 07.46.20 | Request a Quote – single-page variant | Phase 2 | T |
| 07.48.42 | Talk to an Engineer | LEAD-01 | T |
| 07.51.30 | Machinery categories board | CAT | T (L) |
| 07.54.38 | Product detail sections board | CAT | T (L) |
| 07.56.36 | Industries overview (v2) | IND-06 | T |
| 07.58.14 | Industry – Furniture Manufacturing | IND | T (L) |
| 08.05.02 | Admin – Sign in | ADM-01 | T |
| 08.05.48 | Admin – Forgot password | ADM-01a | T |
| 08.10.19 | Admin – Reset password + success | ADM-01a | T |
| 08.10.24 | Admin – Dashboard | ADM | V |

Admin screens beyond login and dashboard (content editors, lead detail, user management) are **not in the mockups** and need UI design.
