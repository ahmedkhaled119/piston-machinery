# PISTON — Epics & User Stories

Related: [01-SRS.md](01-SRS.md). Priority uses MoSCoW. AC = Acceptance Criteria (Given/When/Then).

## Epic Overview
| Epic | Name | SRS modules | Release |
|---|---|---|---|
| E1 | Site Shell, Navigation & Localization | GEN, NFR-12 | MVP |
| E2 | Product Catalogue | CAT | MVP |
| E3 | Industries & Solutions | IND, SOL | MVP |
| E4 | Request a Quote via WhatsApp | RFQ | MVP |
| E5 | Lead Capture (Engineer, Contact, Meeting, Newsletter) | LEAD | MVP |
| E6 | Content Hub (Case Studies, Projects, News, Videos, Events) | CNT | MVP |
| E7 | Support & Spare Parts | SUP | MVP |
| E8 | Admin Portal — CMS | ADM-06..08, ADM-12 | MVP |
| E9 | Admin Portal — Leads & Tickets | ADM-10, ADM-11, ADM-09 | MVP |
| E10 | Admin Portal — Administration & Security | ADM-01, ADM-14..17 | MVP |
| E11 | Integrations & Analytics | INT | MVP |

---

## E1 — Site Shell, Navigation & Localization
**US-1.1 (M)** As a visitor, I want a consistent header and mega-menu so I can reach products, industries, support and contact from any page.
- AC1: Given any public page, the header shows logo, menu, search, language selector and "Request a Quote".
- AC2: Given a mobile viewport, the menu collapses into a hamburger with the same items.

**US-1.2 (M)** As an Arabic-speaking visitor, I want to switch the site to Arabic so I can read it in my language.
- AC1: When I select Arabic, I stay on the equivalent page and the layout is mirrored (RTL).
- AC2: The URL contains the language segment (e.g. `/ar/...`) and the choice persists across pages.
- AC3: If an item isn't translated, the English version is shown with a visible notice (BR-09).

**US-1.3 (M)** As a visitor, I want to search machines and content so I can find what I need quickly.
- AC1: Results are grouped in tabs with counts (All, Machines, Solutions, Support Manuals, Spare Parts, Articles & News).
- AC2: Only published content in the current language is returned.
- AC3: I can refine by content type, industry and machine type, and see suggested/popular searches.
- AC4: With no relevant results, I can submit a request to the team.

---

## E2 — Product Catalogue
**US-2.1 (M)** As a prospect, I want to browse machines by category so I can compare options.
- AC1: Category tabs/sidebar show the number of products per category.
- AC2: I can search, sort, paginate and switch grid/list view.
- AC3: I can filter by industry, machine type, power range (kW), capacity, application and availability.

**US-2.1a (S)** As a prospect, I want to compare machines side by side.
- AC1: "Add to Compare" adds the machine to a sticky compare bar showing the count.
- AC2: "Compare Machines" shows key specs side by side.

**US-2.1b (S)** As a prospect, I want to spin a 360° view of a machine and inspect its components before buying.
- AC1: I can drag to rotate, zoom and go fullscreen.
- AC2: Clicking a hotspot or a component in the list shows its description and specs.
- AC3: True 3D (exploded view, measure, 3D download) is Phase 2.

**US-2.2 (M)** As a prospect, I want a detailed product page with specs, videos and downloads so I can evaluate a machine.
- AC1: Tabs: Overview, Key Features, Technical Specifications, Videos, Downloads, Related Products.
- AC2: "Download Brochure" fires an analytics event.

**US-2.3 (S)** As a prospect, I want to add several machines to a quote list so I can ask for pricing on all of them in one WhatsApp message.
- AC1: Given I click "Add to quote list", the machine appears in my quote list with quantity 1.
- AC2: The list survives navigation within my browser session and is never stored on the server (BR-14).

---

## E3 — Industries & Solutions
**US-3.1 (M)** As a factory owner, I want to see a complete solution for my industry so I understand which machines I need.
- AC1: The industry page shows the process steps in order and the recommended machine chain.
- AC2: Key benefits show value + label (e.g. "+25% Production Capacity").

**US-3.2 (S)** As a factory owner, I want to start a quote from the recommended solution so I don't have to pick machines one by one.
- AC1: "Build your production line" adds all recommended machines to my quote list.

**US-3.3 (M)** As a prospect, I want a Machine Finder to get machine recommendations based on my needs.
- AC1: 5 steps: Industry → Operation → Material (multi-select) → Production (volume, precision, workshop size) → Results.
- AC2: Results show a Best Match with match score %, reasons, other options with scores, and a complete solution for my industry.
- AC3: From results I can view details, compare, request a quote, build a production line or talk to an expert.
- AC4: My selections are shown in a summary sidebar and I can go back without losing them.

**US-3.4 (M, UI deferred — Q-15)** As a prospect, I want a Production Line Builder to compose a full line and send it for a quote via WhatsApp.

**US-3.5 (M)** As a prospect with special needs, I want to request a custom solution.

---

## E4 — Request a Quote via WhatsApp
> Decision: quotes are a direct WhatsApp conversation, no web form, no tracking (SRS §3.5). The web RFQ wizard is Phase 2.

**US-4.1 (M)** As a prospect, I want "Request a Quote" to open WhatsApp with Piston sales so I can talk to them directly.
- AC1: Given I click "Request a Quote" on any page, WhatsApp opens (app on mobile, WhatsApp Web/Desktop on desktop) with the Sales number configured in Admin.
- AC2: The message is pre-filled in my site language with the product model(s) and the page I came from; I can edit it before sending.
- AC3: Before leaving the site I see a short notice that the conversation continues on WhatsApp.

**US-4.2 (S)** As a prospect, I want to send my whole quote list in one message.
- AC1: The message lists each machine with model, name and quantity.
- AC2: I can change quantities or remove items before sending.

**US-4.3 (S)** As a desktop visitor without WhatsApp, I want to see the number and a QR code so I can continue on my phone.

**US-4.4 (S)** As marketing, I want each quote click logged anonymously so I can measure demand per product and source page.
- AC1: The log stores products, source page, language, coarse country and time — no personal data.
- AC2: A GA4 event fires only after analytics consent.

---

## E5 — Lead Capture
**US-5.1 (M)** As a prospect, I want to request a call with an engineer so I get expert advice.
**US-5.2 (M)** As a visitor, I want to send a contact message choosing a subject so it reaches the right team.
**US-5.3 (S)** As a trade-show visitor, I want to schedule a meeting at the booth.
**US-5.4 (S)** As a visitor, I want to subscribe to the newsletter.

**US-5.5 (S)** As a customer, I want to submit my story, project or video so Piston can feature it.
- AC1: My submission is not public until an admin approves it (BR-12).
- AC2: I receive a confirmation email.
- AC (all forms): CAPTCHA/rate limit applied; consent checkbox required; confirmation shown; reference generated; notification sent.
- AC (newsletter): double opt-in email is required before the subscription is active.

---

## E6 — Content Hub
**US-6.1 (M)** As a prospect, I want to filter case studies by industry, solution type, region and results so I find stories similar to my business.
- AC1: Filter options show counts; "Clear all" resets them.
- AC2: Content-type tabs show totals (All, Case Studies, Projects, News, Videos).

**US-6.2 (M)** As a prospect, I want detailed project pages (challenge, solution, installation, results, feedback, gallery, documents) so I trust Piston's capability.
- AC1: Tabs are deep-linkable (the URL reflects the active tab).
- AC2: "Project at a Glance" shows machines installed and before→after metrics.

**US-6.3 (M)** As a prospect, I want to read news articles and watch videos.

**US-6.4 (M)** As a trade-show visitor, I want event details (dates, booth, team, exhibited machines, travel info) so I can plan my visit.
- AC1: Only events not in Draft status are public (BR-04).

---

## E7 — Support & Spare Parts
**US-7.0 (M)** As an existing customer, I want to select my machine (and optionally enter my serial number) so I only see resources for my machine.
- AC1: I get help on where to find the serial number.

**US-7.1 (M)** As an existing customer, I want to download the manuals and guides for my machine (user manual, installation, maintenance, electrical diagrams, troubleshooting, safety, software updates).
**US-7.2 (M)** As an existing customer, I want to request technical assistance (expert, remote or on-site) with my machine model, serial number and photos, without logging in.
- AC1: I receive a ticket number by email.
**US-7.3 (M)** As an existing customer, I want to find spare parts by part number, name or by navigating my machine's components, and add them to a parts list to request a quote on WhatsApp.
- AC1: Part details show part number, description, compatibility, stock status and warranty — no prices.
- AC2: "Request Quote" opens WhatsApp (Spare Parts number) with the part numbers and quantities pre-filled.
**US-7.3a (S)** As an existing customer, I want to upload a photo of a part so a specialist can identify it.
**US-7.4 (M)** As a visitor, I want to search the FAQ.
**US-7.5 (S)** As an existing customer, I want to watch setup, operation and maintenance videos for my machine.

---

## E8 — Admin Portal: CMS
**US-8.1 (M)** As a content editor, I want to create and edit products with specs, gallery and downloads in each language.
- AC1: The editor shows the translation status per language.
- AC2: Changes go live without a deployment (NFR-13).

**US-8.2 (M)** As a content editor, I want to manage industries, projects, case studies, news, videos and events with a Draft/Published workflow and scheduled publishing.

**US-8.3 (M)** As a content editor, I want a media library to upload and reuse images, videos and PDFs, with alt text per language.

---

## E9 — Admin Portal: Leads & Tickets
**US-9.1 (M)** As a sales engineer, I want an inbox of engineer, contact and meeting requests with status, assignee and age so I respond within 24 hours.
- AC1: The list shows Reference, Name, Company, Type, Status, Received time.
- AC2: I can filter by status, type, country and date, and export to CSV/Excel.
- AC3: Each status change is logged.

**US-9.2 (M)** As a sales engineer, I want to add internal notes and download the customer's attachments.
- AC1: Attachments download through time-limited links, and only after the virus scan passes.

**US-9.3 (M)** As a support agent, I want to manage tickets through New / In Progress / Waiting / Resolved.

---

## E10 — Admin Portal: Administration & Security
**US-10.1 (M)** As an administrator, I want to manage users and roles so each person only accesses what they need.
- AC1: Roles: Administrator, Content Editor, Sales Engineer, Support Agent (configurable permissions).

**US-10.2 (M)** As an administrator, I want MFA and account lockout so the portal is protected.

**US-10.2a (M)** As an internal user, I want to reset my forgotten password via an emailed link.
- AC1: The reset link is single-use and expires.
- AC2: The new password must have ≥ 8 characters with upper, lower, number and special character; a strength meter is shown.
- AC3: The response doesn't reveal whether the email exists.

**US-10.3 (M)** As an administrator, I want a dashboard with KPIs, lead activity, content overview, recent activity, ticket overview and upcoming events.
- AC1: A date-range filter applies to all widgets.

**US-10.4 (M)** As an administrator, I want audit and activity logs so I can trace who changed what.

**US-10.5 (M)** As an administrator, I want to manage website settings, SEO and languages without developers.

**US-10.6 (M)** As an administrator, I want to edit the company figures and business hours in one place so every page shows the same official values.
- AC1: I can edit years of experience, countries served, machines installed, projects delivered, distributors and satisfaction %.
- AC2: I can set hours per channel (Sales, Support, Spare Parts) with days, times and timezone.
- AC3: Changes appear on all pages (home, about, contact, support) without deployment.

**US-10.7 (M)** As an administrator, I want to manage the WhatsApp numbers and pre-filled message templates per language.

---

## E11 — Integrations & Analytics
**US-11.1 (M)** As marketing, I want GA4 conversion events (WhatsApp quote click, WhatsApp parts click, engineer request, brochure download, contact submit) so I can measure campaign ROI.
- AC1: Events fire only after analytics consent is given.

**US-11.2 (M)** As a visitor, I want to contact Piston on WhatsApp in one click (click-to-chat).

**US-11.3 (M)** As a visitor and as staff, I want email notifications for every submission, in the visitor's language.
